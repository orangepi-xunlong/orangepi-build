export VDPAU_DRIVER=sunxi
