// SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note
/*
 * Copyright (c) 2019 Synopsys, Inc. and/or its affiliates.
 *
 * Author: Vitor Soares <vitor.soares@synopsys.com>
 */

#ifndef _LINUX_I3C_DEVICE_H
#define _LINUX_I3C_DEVICE_H

#include <linux/types.h>

#endif /* _LINUX_I3C_DEVICE_H */
